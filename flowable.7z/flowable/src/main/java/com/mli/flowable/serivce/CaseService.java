package com.mli.flowable.serivce; // 假設你的 package 名稱

import com.mli.flowable.dto.CaseDto;
import com.mli.flowable.vo.CaseStartVO;
import com.mli.flowable.vo.TaskVO;
import org.flowable.engine.HistoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.task.api.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 案件流程 Service
 */
@Service
public class CaseService {

    /** Flowable 執行服務 - 用來啟動流程 */
    @Autowired
    private RuntimeService runtimeService;

    /** Flowable 任務服務 - 用來操作任務（完成、查詢） */
    @Autowired
    private TaskService taskService;

    /** Flowable 歷史服務 - 後續可查歷史軌跡 */
    @Autowired
    private HistoryService historyService;

    /**
     * 1. 新增案件並啟動 Flowable 流程
     */
    @Transactional
    public CaseStartVO startCase(CaseDto caseDto) {
        // 準備流程變數
        Map<String, Object> variables = new HashMap<>();
        variables.put("assignee", caseDto.getCreator());     // 所有任務先指派給建立者
        variables.put("caseNo", caseDto.getCaseNo());
        variables.put("title", caseDto.getTitle());
        variables.put("description", caseDto.getDescription());

        // 啟動流程實例（key 對應 BPMN 中的 process id）
        ProcessInstance pi = runtimeService.startProcessInstanceByKey("caseProcess", variables);

        // 取得目前第一個待辦任務名稱（取件）
        org.flowable.task.api.Task firstTask = taskService.createTaskQuery()
                .processInstanceId(pi.getId())
                .singleResult();

        String currentTaskName = firstTask != null ? firstTask.getName() : "已結案";

        // 封裝回傳 VO
        return new CaseStartVO(pi.getId(), caseDto.getCaseNo(), currentTaskName);
    }

    /**
     * 2. 完成目前任務，送到下一關
     */
    @Transactional
    public void completeTask(String taskId, String assignee) {
        // 安全檢查：確認此任務確實指派給該使用者
        org.flowable.task.api.Task task = taskService.createTaskQuery()
                .taskId(taskId)
                .taskAssignee(assignee)
                .singleResult();

        if (task == null) {
            throw new RuntimeException("任務不存在或您無權限執行此操作（taskId: " + taskId + "）");
        }

        // 完成任務（第二個參數為流程變數，這裡先傳空，可擴充審核意見等）
        taskService.complete(taskId, new HashMap<>());
    }

    /**
     * 取得指定使用者的待辦任務清單
     */
    public List<TaskVO> getTasks(String assignee) {
        List<Task> tasks = taskService.createTaskQuery()
                .processDefinitionKey("caseProcess")
                .taskAssignee(assignee)
                .orderByTaskCreateTime().desc()
                .list();

        return tasks.stream()
                .map(TaskVO::new)
                .collect(Collectors.toList());
    }

    /**
     * 查詢案件目前所在階段
     */
    public String getCurrentTaskName(String processInstanceId) {
        org.flowable.task.api.Task task = taskService.createTaskQuery()
                .processInstanceId(processInstanceId)
                .singleResult();
        return task != null ? task.getName() : "查無資料";
    }
}