package com.mli.flowable.controller;

import com.mli.flowable.dto.CaseDto;
import com.mli.flowable.serivce.CaseService;
import com.mli.flowable.vo.CaseStartVO;
import com.mli.flowable.vo.TaskVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * 案件流程 REST API 控制器
 */
@RestController
@RequestMapping("/api/case")
@Tag(name = "案件流程控管", description = "案件五階段流程：取件 → 建檔 → 審核 → 送核 → 結案")
public class CaseController {

    @Autowired
    private CaseService caseService;

    /**
     * 1. 新增案件並啟動流程
     */
    @PostMapping("/start")
    @Operation(summary = "新增案件", description = "建立案件並啟動 Flowable 流程，第一關為「取件」")
    public ResponseEntity<CaseStartVO> startCase(@RequestBody @Valid CaseDto caseDto) {
        CaseStartVO caseStartVO = caseService.startCase(caseDto);
        return ResponseEntity.ok(caseStartVO);
    }

    /**
     * 2. 完成目前任務，送到下一關
     */
    @PostMapping("/complete")
    @Operation(summary = "送到下一關", description = "根據 taskId 完成目前任務，自動流轉到下一階段")
    public ResponseEntity<Void> completeTask(
            @RequestParam String taskId,
            @RequestParam String assignee) {   // 正式環境請改用登入者資訊

        caseService.completeTask(taskId, assignee);
        return ResponseEntity.ok().build();
    }

    /**
     * 取得個人目前待辦任務
     */
    @GetMapping("/tasks")
    @Operation(summary = "取得我的待辦任務")
    public ResponseEntity<List<TaskVO>> getTasks(@RequestParam String assignee) {
        List<TaskVO> list = caseService.getTasks(assignee);
        return ResponseEntity.ok(list);
    }

    /**
     * 查詢案件目前在哪一關
     */
    @GetMapping("/status/{processInstanceId}")
    @Operation(summary = "查詢案件目前階段")
    public ResponseEntity<String> getStatus(@PathVariable String processInstanceId) {
        String current = caseService.getCurrentTaskName(processInstanceId);
        return ResponseEntity.ok(current);
    }
}