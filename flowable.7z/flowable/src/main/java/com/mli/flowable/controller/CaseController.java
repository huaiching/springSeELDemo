package com.mli.flowable.controller;

import com.mli.flowable.dto.CaseRequest;
import io.swagger.v3.oas.annotations.Operation;
import org.flowable.engine.HistoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.history.HistoricActivityInstance;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.task.api.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RestController
@RequestMapping("/api/case")
public class CaseController {

    @Autowired
    private RuntimeService runtimeService;

    @Autowired
    private TaskService taskService;

    @Autowired
    private HistoryService historyService;

    // 1. 啟動流程
    @PostMapping("/start")
    @Operation(summary = "啟動流程", description = "啟動流程 API")
    public ResponseEntity<Map<String, Object>> startCase(@RequestBody CaseRequest request) {
        Map<String, Object> variables = new HashMap<>();
        variables.put("pickupUser", request.getPickupUser());
        variables.put("createFileUser", request.getCreateFileUser());

        ProcessInstance pi = runtimeService.startProcessInstanceByKey(
                "caseProcess", request.getCaseNo(), variables);

        Map<String, Object> result = new HashMap<>();
        result.put("message", "案件已啟動成功");
        result.put("processInstanceId", pi.getId());
        result.put("businessKey", pi.getBusinessKey());
        return ResponseEntity.ok(result);
    }

    // 2. 查詢個人待辦
    @GetMapping("/tasks")
    @Operation(summary = "查詢個人待辦", description = "查詢個人待辦 API")
    public ResponseEntity<List<Map<String, Object>>> getMyTasks(@RequestParam String userId) {
        // 個人任務
        List<Task> assigneeTasks = taskService.createTaskQuery()
                .taskAssignee(userId)
                .active()
                .orderByTaskCreateTime().desc()
                .list();

        // 群組可認領任務
        List<Task> candidateTasks = taskService.createTaskQuery()
                .taskCandidateUser(userId)
                .active()
                .orderByTaskCreateTime().desc()
                .list();

        List<Map<String, Object>> allTasks = Stream.concat(assigneeTasks.stream(), candidateTasks.stream())
                .map(task -> {
                    Map<String, Object> map = new HashMap<>();
                    map.put("taskId", task.getId());
                    map.put("taskName", task.getName());
                    map.put("processInstanceId", task.getProcessInstanceId());
                    map.put("createTime", task.getCreateTime());
                    map.put("assignee", task.getAssignee());

                    // 關鍵修正：用 runtimeService 查 BusinessKey
                    ProcessInstance pi = runtimeService.createProcessInstanceQuery()
                            .processInstanceId(task.getProcessInstanceId())
                            .singleResult();
                    String businessKey = (pi != null) ? pi.getBusinessKey() : null;
                    map.put("businessKey", businessKey);

                    return map;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(allTasks);
    }

    // 3. 認領任務（群組任務用）
    @Operation(summary = "認領任務（群組任務用）", description = "認領任務（群組任務用） API")
    @PostMapping("/claim/{taskId}")
    public ResponseEntity<String> claimTask(@PathVariable String taskId,
                                            @RequestParam String userId) {
        taskService.claim(taskId, userId);
        return ResponseEntity.ok("任務已認領");
    }

    // 4. 完成任務
    @PostMapping("/complete/{taskId}")
    @Operation(summary = "完成任務", description = "完成任務 API")
    public ResponseEntity<String> completeTask(@PathVariable String taskId,
                                               @RequestBody(required = false) Map<String, Object> variables) {
        if (variables == null) variables = new HashMap<>();
        taskService.complete(taskId, variables);
        return ResponseEntity.ok("任務已完成");
    }

    // 5. 查詢案件歷史
    @Operation(summary = "查詢案件歷史", description = "查詢案件歷史 API")
    @GetMapping("/history/{businessKey}")
    public ResponseEntity<?> getHistory(@PathVariable String businessKey) {
        HistoricProcessInstance hpi = historyService.createHistoricProcessInstanceQuery()
                .processInstanceBusinessKey(businessKey)
                .singleResult();

        if (hpi == null) {
            return ResponseEntity.badRequest().body("找不到案件編號：" + businessKey);
        }

        List<HistoricActivityInstance> activities = historyService
                .createHistoricActivityInstanceQuery()
                .processInstanceId(hpi.getId())
                .orderByHistoricActivityInstanceStartTime().asc()
                .list();

        Map<String, Object> result = new HashMap<>();
        result.put("businessKey", businessKey);
        result.put("processInstanceId", hpi.getId());
        result.put("startTime", hpi.getStartTime());
        result.put("endTime", hpi.getEndTime());
        result.put("status", hpi.getEndTime() != null ? "已結案" : "進行中");
        result.put("activities", activities);

        return ResponseEntity.ok(result);
    }
}