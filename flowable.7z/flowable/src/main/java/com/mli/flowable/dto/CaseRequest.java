package com.mli.flowable.dto;

public class CaseRequest {
    private String caseNo;        // 案件編號
    private String title;         // 案件標題
    private String pickupUser;    // 取件人
    private String createFileUser; // 建檔人

    public String getCaseNo() {
        return caseNo;
    }

    public void setCaseNo(String caseNo) {
        this.caseNo = caseNo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPickupUser() {
        return pickupUser;
    }

    public void setPickupUser(String pickupUser) {
        this.pickupUser = pickupUser;
    }

    public String getCreateFileUser() {
        return createFileUser;
    }

    public void setCreateFileUser(String createFileUser) {
        this.createFileUser = createFileUser;
    }

    @Override
    public String toString() {
        return "CaseRequest{" +
                "caseNo='" + caseNo + '\'' +
                ", title='" + title + '\'' +
                ", pickupUser='" + pickupUser + '\'' +
                ", createFileUser='" + createFileUser + '\'' +
                '}';
    }
}
